// UK lang variables
tinyMCE.addI18n('en.caption',{
desc : 'Insert/Edit Caption',
'delete' : 'Delete Caption'
});

