// UK lang variables
tinyMCE.addI18n('en.filemanager_dlg',{
icon: 'Icon',
size: 'Size',
text: 'Text',
date: 'Date',
'replace_text': 'Replace file link text with file name?',
no_src: 'Please select a file or ent a file URL',
no_text: 'Text for the file link is required'
});
